import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addPost } from './store/postsSlice'
import PostCard from './components/PostCard'

export default function App() {
  const [newPost, setNewPost] = useState('')
  const posts = useSelector((state) => state.posts.posts)
  const dispatch = useDispatch()

  function submitPost(event) {
    event.preventDefault()
    if (!newPost.trim()) return
    dispatch(addPost(newPost))
    setNewPost('')
  }

  return (
    <main className="page-shell">
      <header className="site-header">
        <div className="brand-mark" aria-hidden="true">S</div>
        <div>
          <h1>Social Book</h1>
          <p>Твоя лента публикаций</p>
        </div>
      </header>

      <section className="feed" aria-label="Лента постов">
        <form className="new-post-form" onSubmit={submitPost}>
          <input value={newPost} onChange={(event) => setNewPost(event.target.value)} placeholder="Новый пост ..." aria-label="Текст нового поста" />
          <button className="button button-primary" type="submit">Добавить</button>
        </form>

        <div className="posts-list">
          {posts.length ? posts.map((post) => <PostCard key={post.id} post={post} />) : (
            <div className="empty-state">
              <span className="empty-icon">✎</span>
              <h2>Пока нет постов</h2>
              <p>Создай первую публикацию с помощью формы выше.</p>
            </div>
          )}
        </div>
        <footer className="feed-footer">Social Book <span>•</span> {posts.length} {posts.length === 1 ? 'пост' : 'поста'}</footer>
      </section>
    </main>
  )
}
