import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { addComment, deleteComment, deletePost, editPost, toggleComments } from '../store/postsSlice'

function EditDialog({ text, onSave, onClose }) {
  const [value, setValue] = useState(text)

  function submit(event) {
    event.preventDefault()
    if (value.trim()) onSave(value)
  }

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <form className="edit-dialog" onSubmit={submit} aria-label="Редактирование поста">
        <textarea value={value} onChange={(event) => setValue(event.target.value)} autoFocus required aria-label="Текст поста" />
        <div className="dialog-actions">
          <button className="button button-primary" type="submit">Подтвердить</button>
          <button className="button button-danger" type="button" onClick={onClose}>Закрыть</button>
        </div>
      </form>
    </div>
  )
}

export default function PostCard({ post }) {
  const dispatch = useDispatch()
  const [commentText, setCommentText] = useState('')
  const [editing, setEditing] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)

  function submitComment(event) {
    event.preventDefault()
    if (!commentText.trim()) return
    dispatch(addComment(post.id, commentText))
    setCommentText('')
    if (!post.commentsOpen) dispatch(toggleComments(post.id))
  }

  function saveEdit(text) {
    dispatch(editPost({ id: post.id, text }))
    setEditing(false)
  }

  return (
    <article className="post-card">
      <p className="post-text">{post.text}</p>
      <div className="post-toolbar">
        <button className="button button-primary comments-toggle" onClick={() => dispatch(toggleComments(post.id))}>
          {post.commentsOpen ? 'Спрятать' : 'Комментарии'}
        </button>
        <span className="comment-count">Количество комментарий - {post.comments.length}</span>
        <div className="post-actions">
          <button className="button button-primary" onClick={() => setEditing(true)}>Изменить</button>
          <button className="button button-danger" onClick={() => setConfirmDelete(true)}>Удалить</button>
        </div>
      </div>

      {post.commentsOpen && (
        <section className="comments-section" aria-label="Комментарии">
          <form className="comment-form" onSubmit={submitComment}>
            <input value={commentText} onChange={(event) => setCommentText(event.target.value)} placeholder="Новый комментарий ..." aria-label="Новый комментарий" />
            <button className="button button-primary" type="submit">Добавить</button>
          </form>
          {post.comments.map((comment) => (
            <div className="comment-row" key={comment.id}>
              <p>{comment.text}</p>
              <button className="button button-danger" onClick={() => dispatch(deleteComment({ postId: post.id, commentId: comment.id }))}>Удалить</button>
            </div>
          ))}
        </section>
      )}

      {editing && <EditDialog text={post.text} onSave={saveEdit} onClose={() => setEditing(false)} />}
      {confirmDelete && (
        <div className="modal-backdrop" role="presentation">
          <div className="confirm-dialog" role="alertdialog" aria-modal="true" aria-label="Удалить пост?">
            <p>Удалить этот пост и все его комментарии?</p>
            <div className="dialog-actions">
              <button className="button button-primary" onClick={() => dispatch(deletePost(post.id))}>Удалить пост</button>
              <button className="button button-danger" onClick={() => setConfirmDelete(false)}>Отмена</button>
            </div>
          </div>
        </div>
      )}
    </article>
  )
}
