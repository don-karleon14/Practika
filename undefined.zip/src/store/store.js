import { configureStore } from '@reduxjs/toolkit'
import postsReducer, { loadPosts } from './postsSlice'

const STORAGE_KEY = 'social-book-posts'
let savedPosts

try {
  savedPosts = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null')
} catch {
  savedPosts = null
}

export const store = configureStore({
  reducer: { posts: postsReducer },
  preloadedState: savedPosts ? { posts: { posts: savedPosts } } : undefined,
})

store.subscribe(() => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store.getState().posts.posts))
  } catch {
    // App remains usable when storage is unavailable.
  }
})

export { loadPosts }
