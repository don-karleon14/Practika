import { createSlice, nanoid } from '@reduxjs/toolkit'

const starterText = 'Сегодня было замечательное предложение пойти поужинать этим вечером. Главное, чтобы погода была преимущественно тёплой.'

const initialState = {
  posts: [
    {
      id: 'post-demo-1',
      text: starterText,
      comments: [
        { id: 'comment-demo-1', text: 'Первый комментарий о выше сказанном посте ...' },
        { id: 'comment-demo-2', text: 'Второй комментарий о выше сказанном посте ...' },
      ],
      commentsOpen: false,
    },
    {
      id: 'post-demo-2',
      text: starterText,
      comments: [],
      commentsOpen: true,
    },
  ],
}

const postsSlice = createSlice({
  name: 'posts',
  initialState,
  reducers: {
    addPost: {
      reducer(state, action) {
        state.posts.unshift(action.payload)
      },
      prepare(text) {
        return { payload: { id: nanoid(), text: text.trim(), comments: [], commentsOpen: true } }
      },
    },
    editPost(state, action) {
      const post = state.posts.find((item) => item.id === action.payload.id)
      if (post) post.text = action.payload.text.trim()
    },
    deletePost(state, action) {
      state.posts = state.posts.filter((post) => post.id !== action.payload)
    },
    toggleComments(state, action) {
      const post = state.posts.find((item) => item.id === action.payload)
      if (post) post.commentsOpen = !post.commentsOpen
    },
    addComment: {
      reducer(state, action) {
        const post = state.posts.find((item) => item.id === action.payload.postId)
        if (post) post.comments.push(action.payload.comment)
      },
      prepare(postId, text) {
        return { payload: { postId, comment: { id: nanoid(), text: text.trim() } } }
      },
    },
    deleteComment(state, action) {
      const { postId, commentId } = action.payload
      const post = state.posts.find((item) => item.id === postId)
      if (post) post.comments = post.comments.filter((comment) => comment.id !== commentId)
    },
    loadPosts(state, action) {
      state.posts = action.payload
    },
  },
})

export const { addPost, editPost, deletePost, toggleComments, addComment, deleteComment, loadPosts } = postsSlice.actions
export default postsSlice.reducer
